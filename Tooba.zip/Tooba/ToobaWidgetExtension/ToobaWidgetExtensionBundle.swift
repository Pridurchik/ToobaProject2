//
//  ToobaWidgetExtensionBundle.swift
//  ToobaWidgetExtension
//
//  Created by Radzhabov Radzhab on 24.08.2025.
//

import WidgetKit
import SwiftUI

@main
struct ToobaWidgetExtensionBundle: WidgetBundle {
    var body: some Widget {
        ToobaWidget()
        ToobaCompactWidget()
        ToobaDonateWidget()
        ToobaMediumWidget()
    }
}
