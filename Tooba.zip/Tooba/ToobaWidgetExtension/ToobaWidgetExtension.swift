//
//  ToobaWidgetExtension.swift
//  ToobaWidgetExtension
//
//  Created by Radzhabov Radzhab on 24.08.2025.
//

import WidgetKit
import SwiftUI

struct ToobaProvider: TimelineProvider {
    func placeholder(in context: Context) -> ToobaEntry {
        ToobaEntry(date: Date(), streakCount: 94, isAtRisk: false)
    }

    func getSnapshot(in context: Context, completion: @escaping (ToobaEntry) -> Void) {
        let entry = ToobaEntry(date: Date(), streakCount: loadStreakCount(), isAtRisk: isAtRisk())
        completion(entry)
    }

    func getTimeline(in context: Context, completion: @escaping (Timeline<ToobaEntry>) -> Void) {
        let currentDate = Date()
        let entry = ToobaEntry(date: currentDate, streakCount: loadStreakCount(), isAtRisk: isAtRisk())
        let refreshDate = Calendar.current.date(byAdding: .minute, value: 15, to: currentDate)!
        let timeline = Timeline(entries: [entry], policy: .after(refreshDate))
        completion(timeline)
    }
    
    private func loadStreakCount() -> Int {
        let sharedDefaults = UserDefaults(suiteName: "group.com.yourcompany.tooba")
        return sharedDefaults?.integer(forKey: "streakCount") ?? 0
    }
    
    private func isAtRisk() -> Bool {
        let sharedDefaults = UserDefaults(suiteName: "group.com.yourcompany.tooba")
        guard let lastDate = sharedDefaults?.object(forKey: "lastCompletionDate") as? Date else {
            return true    // если даты нет — сразу риск
        }
        let calendar = Calendar.current
        return !calendar.isDateInToday(lastDate)
    }

}

struct ToobaEntry: TimelineEntry {
    let date: Date
    let streakCount: Int
    let isAtRisk: Bool
}

struct ToobaWidgetEntryView: View {
    var entry: ToobaProvider.Entry
    @Environment(\.widgetFamily) var family

    var body: some View {
        
        VStack(spacing: 8) {
            
            switch family {
            case .systemSmall:
                VStack(spacing: 8) {
                    Text(formattedStreak(entry.streakCount))
                        .font(.system(size: 48, weight: .bold, design: .rounded)).foregroundColor(Color(red: 29/255, green: 73/255, blue: 21/255))


                    Image(entry.isAtRisk ? "flameIconRisk" : "flameIconStatus")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 72, height: 72)

                    Spacer()
                }
                .padding()
                .containerBackground(for: .widget) { Color.white }
            default:
                Text("Unsupported")
            }
        }
    }
    
    func formattedStreak(_ n: Int) -> String {
        if n < 1000 { return "\(n)" }
        let rounded = Double(n) / 1000
        if rounded.truncatingRemainder(dividingBy: 1) == 0 {
            return "\(Int(rounded))k"
        } else {
            return String(format: "%.1fk", rounded)
        }
    }

}

struct ToobaWidget: Widget {
    let kind: String = "ToobaWidget"
    
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: ToobaProvider()) { entry in
            ToobaWidgetEntryView(entry: entry)
        }
        .configurationDisplayName("Tooba Streak")
        .description("Отслеживает вашу ежедневную серию.")
        .supportedFamilies([.systemSmall, .systemMedium, .systemLarge])
    }
}
