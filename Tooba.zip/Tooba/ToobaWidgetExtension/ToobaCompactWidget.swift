//
//  ToobaCompactWidget.swift
//  Tooba
//
//  Created by Radzhabov Radzhab on 24.08.2025.
//

import WidgetKit
import SwiftUI

struct ToobaCompactProvider: TimelineProvider {
    func placeholder(in context: Context) -> ToobaCompactEntry {
        ToobaCompactEntry(date: Date(), streakCount: 7, isAtRisk: false)
    }

    func getSnapshot(in context: Context, completion: @escaping (ToobaCompactEntry) -> Void) {
        let entry = makeEntry()
        completion(entry)
    }

    func getTimeline(in context: Context, completion: @escaping (Timeline<ToobaCompactEntry>) -> Void) {
        let entry = makeEntry()
        let timeline = Timeline(entries: [entry], policy: .never)
        completion(timeline)
    }

    private func makeEntry() -> ToobaCompactEntry {
        let sharedDefaults = UserDefaults(suiteName: "group.com.yourcompany.tooba")
        let streakCount = sharedDefaults?.integer(forKey: "streakCount") ?? 0
        let lastDate = sharedDefaults?.object(forKey: "lastCompletionDate") as? Date
        let calendar = Calendar.current
        let isAtRisk = !(lastDate != nil && calendar.isDateInToday(lastDate!))
        return ToobaCompactEntry(date: Date(), streakCount: streakCount, isAtRisk: isAtRisk)
    }
}

struct ToobaCompactEntry: TimelineEntry {
    let date: Date
    let streakCount: Int
    let isAtRisk: Bool
}

struct ToobaCompactWidgetEntryView: View {
    var entry: ToobaCompactEntry

    var body: some View {
        VStack(spacing: 8) {
            
            Image(entry.isAtRisk ? "flameIconRisk" : "flameIconStatus")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 48, height: 48)

            Text(formattedStreak(entry.streakCount))
                .font(.system(size: 40, weight: .bold, design: .rounded))
                .foregroundColor(Color(red: 29/255, green: 73/255, blue: 21/255))

            Text(pluralizeDays(entry.streakCount))
                .font(.system(size: 16, weight: .medium, design: .rounded))
                .foregroundColor(Color(red: 29/255, green: 73/255, blue: 21/255))
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .containerBackground(for: .widget) { Color.white }
    }

    // Форматирование streak count для >1000
    func formattedStreak(_ n: Int) -> String {
        if n < 1000 { return "\(n)" }
        let rounded = Double(n)/1000
        if rounded.truncatingRemainder(dividingBy: 1) == 0 {
            return "\(Int(rounded))k"
        } else {
            return String(format: "%.1fk", rounded)
        }
    }

    // Правильное склонение дней
    func pluralizeDays(_ n: Int) -> String {
        let rest10 = n % 10
        let rest100 = n % 100
        if rest10 == 1 && rest100 != 11 {
            return "день в ударе"
        } else if (2...4).contains(rest10) && !(12...14).contains(rest100) {
            return "дня в ударе"
        } else {
            return "дней в ударе"
        }
    }
}

struct ToobaCompactWidget: Widget {
    let kind: String = "ToobaCompactWidgetс"
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: ToobaCompactProvider()) { entry in
            ToobaCompactWidgetEntryView(entry: entry)
        }
        .configurationDisplayName("Tooba Compact Streak")
        .description("Ещё один виджет, который отслеживает вашу серию.")
        .supportedFamilies([.systemSmall])
    }
}

