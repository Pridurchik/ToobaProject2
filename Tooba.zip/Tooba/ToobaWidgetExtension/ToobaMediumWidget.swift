//
//  ToobaMediumWidget.swift
//  Tooba
//
//  Created by Radzhabov Radzhab on 24.08.2025.
//

import WidgetKit
import SwiftUI

struct ToobaMediumEntry: TimelineEntry {
    let date: Date
    let streakCount: Int
    let isAtRisk: Bool
    let donationMade: Bool
}

struct ToobaMediumProvider: TimelineProvider {
    func placeholder(in context: Context) -> ToobaMediumEntry {
        ToobaMediumEntry(date: Date(), streakCount: 7, isAtRisk: false, donationMade: false)
    }
    func getSnapshot(in context: Context, completion: @escaping (ToobaMediumEntry) -> Void) {
        completion(loadEntry())
    }
    func getTimeline(in context: Context, completion: @escaping (Timeline<ToobaMediumEntry>) -> Void) {
        let entry = loadEntry()
        // Можно обновлять хоть каждые 15мин, но reloadAllTimelines в app делает обновление мгновенно
        let next = Calendar.current.date(byAdding: .minute, value: 15, to: Date())!
        completion(Timeline(entries: [entry], policy: .after(next)))
    }
    private func loadEntry() -> ToobaMediumEntry {
        let sharedDefaults = UserDefaults(suiteName: "group.com.yourcompany.tooba")
        let streakCount = sharedDefaults?.integer(forKey: "streakCount") ?? 0
        let lastDate = sharedDefaults?.object(forKey: "lastCompletionDate") as? Date
        let calendar = Calendar.current
        let isAtRisk = !(lastDate != nil && calendar.isDateInToday(lastDate!))
        let donationMade = sharedDefaults?.bool(forKey: "donationMade") ?? false
        return ToobaMediumEntry(
            date: Date(),
            streakCount: streakCount,
            isAtRisk: isAtRisk,
            donationMade: donationMade
        )
    }
}

struct ToobaMediumWidgetEntryView: View {
    var entry: ToobaMediumEntry

    var body: some View {
        HStack {
            // --- S T R E A K ---
            VStack(spacing: 10) {
                Image(entry.isAtRisk ? "flameIconRisk" : "flameIconStatus")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 52, height: 52)
                Text(formattedStreak(entry.streakCount))
                    .font(.system(size: 40, weight: .bold, design: .rounded))
                    .foregroundColor(Color(red: 29/255, green: 73/255, blue: 21/255))
                Text(pluralizeDays(entry.streakCount))
                    .font(.system(size: 16, weight: .medium, design: .rounded))
                    .foregroundColor(Color(red: 29/255, green: 73/255, blue: 21/255))
            }
            .frame(maxWidth: .infinity)

            // --- D O N A T E ---
            VStack(spacing: 16) {
                Image(systemName: entry.donationMade ? "heart.fill" : "heart")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 72, height: 72)
                    .foregroundColor(Color(red: 0/255, green: 206/255, blue: 98/255))
                Text(entry.donationMade ? "Спасибо" : "Пожертвовать")
                    .font(.system(size: 16, weight: .bold, design: .rounded))
                    .foregroundColor(Color(red: 29/255, green: 73/255, blue: 21/255))
            }
            .frame(maxWidth: .infinity)
        }
        .containerBackground(for: .widget) { Color.white }
    }

    func formattedStreak(_ n: Int) -> String {
        if n < 1000 { return "\(n)" }
        let rounded = Double(n) / 1000
        if rounded.truncatingRemainder(dividingBy: 1) == 0 {
            return "\(Int(rounded))k"
        } else {
            return String(format: "%.1fk", rounded)
        }
    }
    func pluralizeDays(_ n: Int) -> String {
        let rest10 = n % 10
        let rest100 = n % 100
        if rest10 == 1 && rest100 != 11 {
            return "день в ударе"
        } else if (2...4).contains(rest10) && !(12...14).contains(rest100) {
            return "дня в ударе"
        } else {
            return "дней в ударе"
        }
    }
}

struct ToobaMediumWidget: Widget {
    let kind: String = "ToobaMediumWidget"
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: ToobaMediumProvider()) { entry in
            ToobaMediumWidgetEntryView(entry: entry)
        }
        .configurationDisplayName("Tooba Medium Стрик и Donate")
        .description("Комбинированный виджет: серия и донат.")
        .supportedFamilies([.systemMedium])
    }
}
