//
//  ToobaDonateWidget.swift
//  Tooba
//
//  Created by Radzhabov Radzhab on 24.08.2025.
//


import WidgetKit
import SwiftUI

struct ToobaDonateProvider: TimelineProvider {
    func placeholder(in context: Context) -> ToobaDonateEntry {
        ToobaDonateEntry(date: Date(), donationMade: false)
    }
    func getSnapshot(in context: Context, completion: @escaping (ToobaDonateEntry) -> Void) {
        let entry = makeEntry()
        completion(entry)
    }
    func getTimeline(in context: Context, completion: @escaping (Timeline<ToobaDonateEntry>) -> Void) {
        let entry = makeEntry()
        let timeline = Timeline(entries: [entry], policy: .after(Date().addingTimeInterval(60*15)))
        completion(timeline)
    }
    private func makeEntry() -> ToobaDonateEntry {
        let sharedDefaults = UserDefaults(suiteName: "group.com.yourcompany.tooba")
        let donationMade = sharedDefaults?.bool(forKey: "donationMade") ?? false
        return ToobaDonateEntry(date: Date(), donationMade: donationMade)
    }
}

struct ToobaDonateEntry: TimelineEntry {
    let date: Date
    let donationMade: Bool
}

struct ToobaDonateWidgetEntryView: View {
    var entry: ToobaDonateEntry
    var body: some View {
        VStack(spacing: 12) {
            // Используем SF Symbols!
            Image(systemName: entry.donationMade ? "heart.fill" : "heart")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 72, height: 72)
                .foregroundColor(.green)
            Text(entry.donationMade ? "Спасибо" : "Пожертвовать")
                .font(.system(size: 16, weight: .bold, design: .rounded))
                .foregroundColor(Color(red: 29/255, green: 73/255, blue: 21/255))
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .containerBackground(for: .widget) { Color.white }
    }
}

struct ToobaDonateWidget: Widget {
    let kind: String = "ToobaDonateWidget"
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: ToobaDonateProvider()) { entry in
            ToobaDonateWidgetEntryView(entry: entry)
        }
        .configurationDisplayName("Tooba Donate")
        .description("Быстрый доступ для пожертвования.")
        .supportedFamilies([.systemSmall])
    }
}
