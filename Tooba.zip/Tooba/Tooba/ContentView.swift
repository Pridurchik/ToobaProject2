//
//  ContentView.swift
//  Tooba
//
//  Created by Radzhabov Radzhab on 24.08.2025.
//

import SwiftUI
import WidgetKit

struct ContentView: View {
    @State private var streakCount: Int = 0
    @State private var donationMade: Bool = false

    var body: some View {
        ScrollView {
            VStack(spacing: 32) {

                // Счётчик streak (демо и мини-контроль)
                VStack(spacing: 16) {
                    Text("Текущий streak: \(streakCount)")
                        .font(.largeTitle)

                    // Мини-кнопки для быстрого теста streak
                    HStack(spacing: 8) {
                        Button("0") { resetStreak() }
                            .buttonStyle(MiniButtonStyle(bg: .red))
                        Button("+10") { addDays(10) }
                            .buttonStyle(MiniButtonStyle(bg: .blue))
                        Button("+50") { addDays(50) }
                            .buttonStyle(MiniButtonStyle(bg: .orange))
                        Button("+100") { addDays(100) }
                            .buttonStyle(MiniButtonStyle(bg: .purple))
                        Button("+1000") { addDays(1000) }
                            .buttonStyle(MiniButtonStyle(bg: .green))
                    }

                    Button("Продолжить серию") {
                        updateStreak()
                    }
                    .padding()
                    .background(Color.green)
                    .foregroundColor(.white)
                    .cornerRadius(8)

                    // Кнопки для презентации статуса streak
                    HStack(spacing: 8) {
                        Button("Показать обычный status") { setDemoStatus(risk: false) }
                            .padding().background(Color.gray).foregroundColor(.white).cornerRadius(8)
                        Button("Показать статус RISK") { setDemoStatus(risk: true) }
                            .padding().background(Color.red).foregroundColor(.white).cornerRadius(8)
                    }
                }

                // Блок Donate (синхронизируется с виджетом Donate)
                VStack(spacing: 16) {

                    HStack(spacing: 16) {
                        Button("Пожертвовать") {
                            setDonation(true)
                        }
                        .padding()
                        .background(Color.green)
                        .foregroundColor(.white)
                        .cornerRadius(10)

                        Button("Сбросить пожертвование") {
                            setDonation(false)
                        }
                        .padding()
                        .background(Color.gray)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                    }
                }
                .padding(.top, 24)
            }
            .padding()
        }
        .onAppear {
            streakCount = loadStreakCount()
            donationMade = loadDonation()
        }
    }

    // ——— Мини-стиль кнопки для streak-акций ———
    struct MiniButtonStyle: ButtonStyle {
        let bg: Color
        func makeBody(configuration: Configuration) -> some View {
            configuration.label
                .font(.system(size: 13, weight: .bold))
                .frame(width: 46, height: 30)
                .background(bg)
                .foregroundColor(.white)
                .cornerRadius(6)
                .opacity(configuration.isPressed ? 0.7 : 1.0)
        }
    }

    // ——— streak: core actions ———
    private func updateStreak() {
        let sharedDefaults = UserDefaults(suiteName: "group.com.yourcompany.tooba")
        streakCount += 1
        sharedDefaults?.set(streakCount, forKey: "streakCount")
        sharedDefaults?.set(Date(), forKey: "lastCompletionDate")
        WidgetCenter.shared.reloadAllTimelines()
    }
    private func loadStreakCount() -> Int {
        let sharedDefaults = UserDefaults(suiteName: "group.com.yourcompany.tooba")
        return sharedDefaults?.integer(forKey: "streakCount") ?? 0
    }
    private func resetStreak() {
        let sharedDefaults = UserDefaults(suiteName: "group.com.yourcompany.tooba")
        streakCount = 0
        sharedDefaults?.set(streakCount, forKey: "streakCount")
        WidgetCenter.shared.reloadAllTimelines()
    }
    private func addDays(_ count: Int) {
        let sharedDefaults = UserDefaults(suiteName: "group.com.yourcompany.tooba")
        streakCount += count
        sharedDefaults?.set(streakCount, forKey: "streakCount")
        WidgetCenter.shared.reloadAllTimelines()
    }
    private func setDemoStatus(risk: Bool) {
        let sharedDefaults = UserDefaults(suiteName: "group.com.yourcompany.tooba")
        if risk {
            let yesterday = Calendar.current.date(byAdding: .day, value: -1, to: Date())!
            sharedDefaults?.set(yesterday, forKey: "lastCompletionDate")
        } else {
            sharedDefaults?.set(Date(), forKey: "lastCompletionDate")
        }
        WidgetCenter.shared.reloadAllTimelines()
    }

    // ——— Donate demo блок ———
    private func setDonation(_ value: Bool) {
        let sharedDefaults = UserDefaults(suiteName: "group.com.yourcompany.tooba")
        sharedDefaults?.set(value, forKey: "donationMade")
        WidgetCenter.shared.reloadAllTimelines()
        donationMade = value
    }
    private func loadDonation() -> Bool {
        let sharedDefaults = UserDefaults(suiteName: "group.com.yourcompany.tooba")
        return sharedDefaults?.bool(forKey: "donationMade") ?? false
    }
}



#Preview {
    ContentView()
}
