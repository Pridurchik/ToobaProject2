//
//  ToobaApp.swift
//  Tooba
//
//  Created by Radzhabov Radzhab on 24.08.2025.
//

import SwiftUI

@main
struct ToobaApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
